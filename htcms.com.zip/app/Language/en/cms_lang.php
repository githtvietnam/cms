<?php  
    return [
        'sidebar'  => [
        	'sb_article' => 'Blog',
        	'sb_article_catalogue' => 'Blog Category',
        	'sb_user' => 'User',
        	'sb_user_catalogue' => 'User Group',
        	'sb_setting' => 'Setting',
        	'sb_language' => 'Language',
            'sb_config' => 'General Configuration',
            'sb_slide' => 'Banner',
            'sb_contactCatalogue' => 'Contact Group',
            'sb_contact' => 'Contact',

        ],
    ];
