<?php  
    return [
        'sidebar'  => [
        	'sb_article' => 'QL Bài Viết',
        	'sb_article_catalogue' => 'QL Nhóm Bài Viết',
        	'sb_user' => 'QL Thành Viên',
        	'sb_user_catalogue' => 'QL Nhóm Thành Viên',
        	'sb_setting' => 'Cấu Hình Chung',
        	'sb_language' => 'QL Ngôn Ngữ',
            'sb_config' => 'Cấu Hình Chung',
            'sb_slide' => 'QL Banner',
            'sb_contactCatalogue' => 'QL Nhóm Liên Hệ',
            'sb_contact' => 'QL Liên Hệ',
        ],
    ];
