<div class="row wrapper border-bottom white-bg page-heading">
	<div class="col-lg-10">
		<h2>Thêm mới Nhóm Liên Hệ</h2>
		<ol class="breadcrumb">
			<li>
				<a href="<?php echo site_url('admin'); ?>">Home</a>
			</li>
			<li class="active"><strong>Thêm mới Nhóm Liên Hệ</strong></li>
		</ol>
	</div>
</div>
<?php echo view('backend/contact/catalogue/store') ?>