<div class="footer">
    <div class="pull-right">
        Welcome to HT VietNam Panel 
    </div>
    <div>
        <strong>Copyright</strong> Công ty HT VietNam <?php echo date('Y'); ?>
    </div>
</div>