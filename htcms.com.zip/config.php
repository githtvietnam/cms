<?php
header('Content-Type: text/html; charset=utf-8');
date_default_timezone_set('Asia/Ho_Chi_Minh');

define('BACKEND_DIRECTORY', 'admin');

define('AUTH', 'HTVIETNAM_');
define('ASSET_BACKEND', 'public/backend/');

define('BASE_URL', 'http://htcms.com/');
define('HTSUFFIX', '.html');

define('DEBUG', 0);
define('COMPRESS', 0);
define('CMS_NAME', 'HT VIETNAM CMS 3.0');


define('HTDBHOST', 'localhost');
define('HTDBUSER', 'root');
define('HTDBPASS', '');
define('HTDBNAME', 'ci4_cms');
